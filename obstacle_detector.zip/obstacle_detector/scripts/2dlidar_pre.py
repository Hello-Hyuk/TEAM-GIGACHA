#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from cmath import inf
import rospy
from std_msgs.msg import Int32
from sensor_msgs.msg import LaserScan
from math import cos,sin
from geometry_msgs.msg import Point32

class lidarParser :

    def __init__(self):
        rospy.init_node('lidar_parser', anonymous=True)
        rospy.Subscriber("/scan", LaserScan, self.laser_callback)       # velodyne's scan msg

        self.obj_pub1= rospy.Publisher('/pre_points', LaserScan, queue_size=1)
        
        rospy.spin()

    def laser_callback(self,msg):
        # obj_msg = Int32()
        # make LaserScan msg -> insert LaserScan
        parsing_scan = LaserScan()
        parsing_scan.header = msg.header
        # print(parsing_scan.header)
        parsing_scan.angle_min = msg.angle_min
        parsing_scan.angle_max = msg.angle_max
        parsing_scan.angle_increment = msg.angle_increment
        parsing_scan.time_increment = msg.time_increment
        parsing_scan.scan_time = msg.scan_time
        parsing_scan.range_min = msg.range_min
        parsing_scan.range_max = msg.range_max
        # angle=msg.angle_min
        # make coordinate and make roi
        for i in range(0, len(msg.ranges)):
            angle = parsing_scan.angle_min + (i * parsing_scan.angle_increment)
            tmp_point=Point32()
            tmp_point.x=msg.ranges[i]*cos(angle)
            tmp_point.y=msg.ranges[i]*sin(angle)
            # print(angle,tmp_point.x,tmp_point.y)
            # angle=angle+(1.0/180.0*pi) # msg.angle_increment # (1.0/180.0*pi)
            # print(msg.angle_increment)
            if tmp_point.x > 0 and tmp_point.x < 15.0:
                if tmp_point.y > -1.5 and tmp_point.y < 1.5:
                    parsing_scan.ranges.append(msg.ranges[i])
                    parsing_scan.intensities.append(255.0)
                else:
                    parsing_scan.ranges.append(inf)
                    parsing_scan.intensities.append(0.0)
            else:
                parsing_scan.ranges.append(inf)
                parsing_scan.intensities.append(0.0)

        # print(parsing_scan)
        # print(obj_msg)
        self.obj_pub1.publish(parsing_scan)

test = lidarParser()
# if __name__ == '__main__':
#     try:
#         test=lidarParser()
#     except rospy.ROSInterruptException:
#         pass
