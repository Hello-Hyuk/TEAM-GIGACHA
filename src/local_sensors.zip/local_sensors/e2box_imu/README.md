# e2box_imu_9dofv4
E2BOX IMU 9DOF V4 ros package

Default baudrate : 115200
Default port : /dev/ttyUSB0
